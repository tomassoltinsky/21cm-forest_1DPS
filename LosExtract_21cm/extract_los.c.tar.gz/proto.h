
/* Function prototypes */

/* extract_los.c */
void read_los();
void write_tau();
void compute_absorption();
void allocate_los_memory();
void free_los_memory();
void MakeLineProfileTable();
