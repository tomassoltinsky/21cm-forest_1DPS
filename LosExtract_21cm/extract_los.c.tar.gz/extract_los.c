#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "global_vars.h"
#include "proto.h"

/* Evaluate Gaussian within this range of sigma */
#define SIGMA 5.0

static double *exp_v2_b2;
static double dx_inv;

double ztime_file;
double fX_name;
char *model;
char *path;

/********************************************************************************/

int main(int argc, char **argv)
{

  int i,j;
  double start, end, tot_cpu_used;
  
  start = clock();
  
  if(argc != 2)
    {
      fprintf(stderr, "\n\nIncorrect argument(s).  Specify:\n\n");
      fprintf(stderr, "<path>     (path to output files)\n");
      fprintf(stderr, "Usage: ./LosExtract <path>\n");
      fprintf(stderr, "\n\n");
      exit(0);
    }
  
  path = argv[1];
  
  ztime_file = 7.500;
  fX_name    = 0.01;
  dvH = 250;

  if(SIGMA > fabs(XMIN))
    {
      printf("\nSIGMA must be less than %.1f\n\n",fabs(XMIN));
      exit(0);
    }
   
  MakeLineProfileTable();
    
    for(j=0; j<1; j++)
    {

      filenum = 0;
      
      for(i=0; i<1; i++)
      {
        printf("\nReading los output at z=%.3f:, file%d:\n",ztime_file,filenum);
        read_los();
        
        printf("\nComputing optical depths...\n");
        compute_absorption();
        printf("Done.\n\n");
        
        write_tau();
        
        free_los_memory();
        
        filenum += 1;
        
      }

      ztime_file += 0.2;
      
    }
      
      
  end = clock();
  tot_cpu_used = (end - start) / CLOCKS_PER_SEC;
  printf("\nTotal CPU time used %lf s\n",tot_cpu_used);
 
  return(0);
}

/********************************************************************************/

void compute_absorption()
{
  
  double atime,vmax,vmax2,rscale,escale,drbin,Hz;
  double H0,rhoc,critH;
  double v2_b2, T_spin_inv;
  double k1_conv,k2_conv,k_21;
  double profile_H1,vdiff_H1;
  double u_H1[nbins],b_H1_inv[nbins],b2_H1_inv[nbins],tau_H1_dR[nbins];
#ifdef TAUWEIGHT
  double rhoker_Hw[nbins],tempker_H1w[nbins];
#endif
  double pcdone,pccount=0.0;
  double t,fhi,flow;
  
  long int i,j,iproc,convol_index,pixel_index,tint;
 
  
  
  atime  = 1.0/(1.0+ztime);
  rscale = (KPC*atime)/h100;        /* comoving kpc/h to cm */
  escale = 1.0e10;                     /* (km s^-1)^2 to (cm s^-1)^2 */
  drbin  = box100/(double)nbins; /* comoving kpc/h */
  
  Hz     = 100.0*h100*sqrt(omegam/(atime*atime*atime)+omegal); /* km s^-1 Mpc^-1 */
  vmax   = box100*Hz*rscale/MPC; /* box size km s^-1 */
  vmax2  = 0.5*vmax;
  H0     = 1.0e7/MPC; /* 100 km s^-1 Mpc^-1 in cgs */ 
  rhoc   = 3.0*(H0*h100)*(H0*h100)/(8.0*PI*GRAVITY); /* g cm^-3 */
  critH  = rhoc*omegab*Xh/(atime*atime*atime); /* g cm^-3*/
  
  k_21    = 3.0*PLANCK*pow(C,3.0)*A10_21/(32.0*PI*pow(NU_21,2.0)*BOLTZMANN);
  k1_conv = 2.0*BOLTZMANN/(HMASS*AMU);
  k2_conv = k_21*rscale*drbin*critH/(sqrt(PI)*HMASS*AMU);



  for(iproc=0; iproc<nlos; iproc++)
    {
      printf("blem_%d\n",iproc);
      for(j=0; j<nbins; j++)
	{
	  convol_index =  j + nbins*iproc;
	  
	  /* Test case where T_kin=100 K and xH1=1.0.. Will need to be updated. */
	  /* T_K_corrected[convol_index] = 0.899;*/
	  /* x_H1_corrected[convol_index]  = 1.0; */
	  /*T_spin_inv = 1.0/T_K_corrected[convol_index];*/ /* assumes Ts=TK, needs to be updated later */
	  T_spin_inv = 1.0/T_S_corrected[convol_index];
	  
#ifdef NOPECVEL
  	  u_H1[j] = velaxis[j]; /* km s^-1 */
#else
	  u_H1[j] = velaxis[j] + velker_H1[convol_index]; /* km s^-1 */
#endif	  
	  
	  b_H1_inv[j]  = 1.0/sqrt(k1_conv*T_K_corrected[convol_index]); /* cm s^-1 */
	  b2_H1_inv[j] = b_H1_inv[j]*b_H1_inv[j]*escale;  /* (km s^-1)^-2 */
	  
	  tau_H1_dR[j] = k2_conv*rhoker_H[convol_index]*x_H1_corrected[convol_index]*b_H1_inv[j]*T_spin_inv;

#ifdef TAUWEIGHT
	  rhoker_Hw[j]    = rhoker_H[convol_index];
	  tempker_H1w[j]  = T_K_corrected[convol_index];
#endif
	  
      	}
   

      for(i=0; i<nbins; i++)
	{
	  pixel_index =  i + nbins*iproc;
	  
	  #pragma omp parallel shared(tau_H1,velaxis,u_H1,b2_H1_inv,exp_v2_b2,tau_H1_dR,i,pixel_index) private(j,v2_b2,vdiff_H1,profile_H1,t,tint,fhi,flow)
	  {
	  #pragma omg for
	  
	  for(j=0; j<nbins; j++)
	    {
	      vdiff_H1 = fabs(velaxis[i] - u_H1[j]);
	      
	      if (vdiff_H1 > vmax2) vdiff_H1 = vmax - vdiff_H1;
	      
	      v2_b2 = vdiff_H1*vdiff_H1*b2_H1_inv[j];
	      
	      t    = (v2_b2 - XMIN) * dx_inv;
	      tint = (int)t;
	      fhi  = t - tint;
	      flow = 1 - fhi;
	      
	      profile_H1 = v2_b2 < SIGMA ? flow*exp_v2_b2[tint]+fhi*exp_v2_b2[tint+1] : 0.0;
	      
	      if (profile_H1 > 0) tau_H1[pixel_index] += tau_H1_dR[j]*profile_H1;
	      

#ifdef TAUWEIGHT
	      /* HI optical depth weighted quantities */
	      rho_tau_H1[pixel_index]  += rhoker_Hw[j]*tau_H1_dR[j]*profile_H1;
	      temp_tau_H1[pixel_index] += tempker_H1w[j]*tau_H1_dR[j]*profile_H1;
#endif	      
	      
	    }
	  }
	    
#ifdef TAUWEIGHT	  
	  rho_tau_H1[pixel_index]  /= tau_H1[pixel_index];
	  temp_tau_H1[pixel_index] /= tau_H1[pixel_index];
#endif
	    
	}
        
      pcdone = 100.0*(double)iproc/((double)nlos-1.0);
      if(pcdone >= pccount)
  	{
  	  printf("%3.2f%%\n",pcdone);
  	  pccount += 10.0;
  	}
    }
    
  for(pixel_index=0; pixel_index<nbins*nlos; pixel_index++)
    {
      floatArray[pixel_index] = (float) tau_H1[pixel_index];
    }
  
}
 
/********************************************************************************/

void read_los()
{
  char fname[400];
  FILE *input;
  
  sprintf(fname, "%s/los/los_21cmREBIN_n500_z%.3f_dv%d_file%d.dat",path,ztime_file,dvH,filenum);
  if(!(input=fopen(fname,"rb")))
    {
      printf("can't open file `%s`\n\n",fname);
      exit(0);
    }
  
  fread(&ztime,sizeof(float),1,input);
  fread(&omegam,sizeof(float),1,input);
  fread(&omegal,sizeof(float),1,input);
  fread(&omegab,sizeof(float),1,input);
  fread(&h100,sizeof(float),1,input);
  fread(&box100,sizeof(float),1,input);
  fread(&Xh,sizeof(float),1,input); /* hydrogen fraction by mass */
  fread(&nbins_read,sizeof(float),1,input);
  fread(&nlos_read,sizeof(float),1,input);
  
  nbins = (int) nbins_read;
  nlos  = (int) nlos_read;
  
  printf("z      = %f\n",ztime);
  printf("fX     = %f\n",fX_name);
  printf("omegaM = %f\n",omegam);
  printf("omegaL = %f\n",omegal);
  printf("omegab = %f\n",omegab);
  printf("h100   = %f\n",h100);
  printf("box100 = %f\n",box100);
  printf("Xh     = %f\n",Xh);
  printf("nbins  = %d\n",nbins);
  printf("nlos   = %d\n",nlos);

  allocate_los_memory();
  
  fread(ilos_read,sizeof(float),nlos,input); /* LOS axis */
  fread(xlos,sizeof(float),nlos,input); /* LOS positions, comoving kpc/h */
  fread(ylos,sizeof(float),nlos,input);
  fread(zlos,sizeof(float),nlos,input);
  fread(posaxis,sizeof(float),nbins,input); /* pixel positions, comoving kpc/h */
  fread(velaxis,sizeof(float),nbins,input); /* pixel positions, km s^-1 */
  fread(rhoker_H,sizeof(float),nbins*nlos,input); /* gas overdensity, Delta=rho/rho_crit */

  fread(rhoker_H1,sizeof(float),nbins*nlos,input); /* n_HI/n_H */
  fread(tempker_H1,sizeof(float),nbins*nlos,input); /* T [K], HI weighted */
  fread(velker_H1,sizeof(float),nbins*nlos,input); /* v_pec [km s^-1], HI weighted */

  fclose(input);

  sprintf(fname, "%s/Corrected_%d_n%d_z%.3f_fX%.2f_dv%d_file%d_ADCOMP.dat",path,nbins,nlos,ztime_file,fX_name,dvH,filenum);
  if(!(input=fopen(fname,"rb")))
    {
      printf("can't open file `%s`\n\n",fname);
      exit(0);
    }
    
  fread(x_H1_corrected,sizeof(float),nbins*nlos,input); /* n_HI/n_H */
  fread(T_K_corrected,sizeof(float),nbins*nlos,input);  /* T [K], HI weighted */
  fread(T_S_corrected,sizeof(float),nbins*nlos,input);  /* T spin, HI weighted */
  
  fclose(input);  


}

/********************************************************************************/

void write_tau()
{
  char fname[400];
  FILE *output;
   
  // sprintf(fname, "%s/tau%d_n%d_21cm_z%.3f.dat",path,nbins,nlos,ztime_file);
  sprintf(fname, "%s/tau%d_n%d_z%.3f_fX%.2f_dv%d_file%d_ADCOMP_para.dat",path,nbins,nlos,ztime_file,fX_name,dvH,filenum);

  if(!(output=fopen(fname,"wb")))
    {
      printf("can't open file `%s`\n\n",fname);
      exit(0);
    }
  fwrite(floatArray,sizeof(float),nbins*nlos,output);
  fclose(output);
 
#ifdef TAUWEIGHT
  sprintf(fname, "%s/weighted_tau%d_n%d_z%.3f_fX%.2f_dv%d_file%d_ADCOMP.dat",path,nbins,nlos,ztime_file,fX_name,dvH,filenum);
  if(!(output=fopen(fname,"wb")))
    {
      printf("can't open file `%s`\n\n",fname);
      exit(0);
    }
  fwrite(rho_tau_H1,sizeof(float),nbins*nlos,output);
  fwrite(temp_tau_H1,sizeof(float),nbins*nlos,output);
  fclose(output);
#endif  
  
}

/********************************************************************************/

void allocate_los_memory()
{  
 
  ilos_read      = (float *)calloc(nlos, sizeof(float));
  if(NULL==ilos_read){free(ilos_read);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  xlos      = (float *)calloc(nlos, sizeof(float));
  if(NULL==xlos){free(xlos);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  ylos      = (float *)calloc(nlos, sizeof(float));
  if(NULL==ylos){free(ylos);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  zlos      = (float *)calloc(nlos, sizeof(float));
  if(NULL==zlos){free(zlos);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  
  posaxis      = (float *)calloc(nbins, sizeof(float));
  if(NULL==posaxis){free(posaxis);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  velaxis      = (float *)calloc(nbins, sizeof(float));
  if(NULL==velaxis){free(velaxis);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  
  rhoker_H     = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==rhoker_H){free(rhoker_H);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}  
  rhoker_H1    = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==rhoker_H1){free(rhoker_H1);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  velker_H1    = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==velker_H1){free(velker_H1);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  tempker_H1   = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==tempker_H1){free(tempker_H1);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}

  tau_H1       = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==tau_H1){free(tau_H1);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}

  x_H1_corrected = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==x_H1_corrected ){free(x_H1_corrected );printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  T_K_corrected  = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==T_K_corrected ){free(T_K_corrected );printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  T_S_corrected  = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==T_S_corrected ){free(T_S_corrected );printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  
  floatArray      = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==floatArray ){free(floatArray );printf("Memory allocation failed in extract_spectra.c\n");exit(0);}  
  
#ifdef TAUWEIGHT
  rho_tau_H1       = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==rho_tau_H1){free(rho_tau_H1);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
  temp_tau_H1       = (float *)calloc(nlos*nbins, sizeof(float));
  if(NULL==temp_tau_H1){free(temp_tau_H1);printf("Memory allocation failed in extract_spectra.c\n");exit(0);}
#endif
  
}

/********************************************************************************/

void free_los_memory()
{  
  free(ilos_read);
  free(xlos);
  free(ylos);
  free(zlos);
  free(posaxis);
  free(velaxis);

  free(rhoker_H);  
  free(rhoker_H1);
  free(velker_H1);
  free(tempker_H1);

  free(x_H1_corrected);
  free(T_K_corrected);
  free(T_S_corrected);

  free(tau_H1);

#ifdef TAUWEIGHT
  free(rho_tau_H1);
  free(temp_tau_H1);
#endif
  
}

/********************************************************************************/
/* Look-up table for Gaussian line profile */

void MakeLineProfileTable(void)
{
  double x, dx;
  int i;
  
  exp_v2_b2 = (double *)calloc(NXTAB+1, sizeof(double));

  if(NULL==exp_v2_b2)
    {
      free(exp_v2_b2);
      printf("Memory allocation failed in extract_spectra.c\n");
      exit(0);
    }

  dx     = (fabs(XMIN)-XMIN) / NXTAB;
  dx_inv = 1.0 / dx;
  
  for(i = 0; i <= NXTAB; i++)
    {
      x = XMIN + dx*i;
      exp_v2_b2[i] = exp(-x);
    }
}

/********************************************************************************/
